image1 = imread('pout.tif');
image2 = imread('cameraman.tif');


% Find dimensions and extent of the FFT
[rows1, cols1] = size(image1);
[rows2, cols2] = size(image2);

rows = max(rows1, rows2);
cols = max(cols1, cols2);

% Take the FFT
image1_FFT=fft2(image1, rows, cols);
image2_FFT=fft2(image2, rows, cols);

% NEW - Find the magnitudes and phase responses
mag1 = abs(image1_FFT);
mag2 = abs(image2_FFT);
pha1 = angle(image1_FFT);
pha2 = angle(image2_FFT);
%Switch magnitude and phase of 2D FFTs
fftChange1 = mag1 .* exp(i*pha2); 
fftChange2= mag2 .* exp(i*pha1);
%Perform inverse 2D FFTs on switched images
imageChanged1 = real(ifft2(fftChange1));
imageChanged2= real(ifft2(fftChange2));
%Calculate limits for plotting
image1min = min(min(abs(imageChanged1)));
image1max = max(max(abs(imageChanged1)));
image2min = min(min(abs(imageChanged2)));
image2max = max(max(abs(imageChanged2)));
%Display switched images
subplot(4, 2, 1);
imshow(image1)
title('Image 1  ')

subplot(4, 2, 2);
 imshow(abs(fftshift(image1_FFT)),[24 100000]), colormap gray
 title('Image 1 FFT2 Magnitude')

subplot(4, 2, 3);
imshow(angle(fftshift(image1_FFT)),[-pi pi]), colormap gray
title('Image 1 FFT2 Phase')

subplot(4,2,4);
imshow(abs(imageChanged1), [image1min image1max]),colormap gray
title('Image 1 with image 2 Phase')
subplot(4, 2, 5);
imshow(image2)
title('Image 2  ')

subplot(4, 2, 6);
 imshow(abs(fftshift(image2_FFT)),[24 100000]), colormap gray
 title('Image 2 FFT2 Magnitude')

subplot(4, 2, 7);
imshow(angle(fftshift(image2_FFT)),[-pi pi]), colormap gray
title('Image 2 FFT2 Phase')

subplot(4,2,8);
imshow(abs(imageChanged2), [image2min image2max]),colormap gray
title('Image 2 with image 1 Phase')











